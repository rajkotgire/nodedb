// possible env options are production,development,test
//this file should never be checked in and env should always point to production
//so that whenever we build application for production ready it will point to
//production env.

const appConfig = {
  env:null
}

module.exports = appConfig;
