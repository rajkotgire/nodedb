const queryConstant = {
  SELECT_ALL_BILL_TYPES:"select * from billtypes"
}

module.exports = queryConstant;
