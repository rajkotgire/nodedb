var mysql = require('mysql');
// const sql = require('mssql');
const appConfig = require('../appConfig.js');
const dbConfig = require('./dbConfig')[appConfig.env || 'development']

var connection = mysql.createConnection(dbConfig);
connection.connect(function(err) {
  console.log("Connetction: "+ JSON.stringify(connection.config));
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }

  console.log('connected as id ' + connection.threadId);
});
// connection.query("select * from billtypes", function (err, results, fields) {
//   console.log("Result: "+results); // results contains rows returned by server
//   console.log("Fields: "+fields); // fields contains extra meta data about results, if available
//   console.log("Erorr: "+err);
// });

module.exports =  connection

// simple query
